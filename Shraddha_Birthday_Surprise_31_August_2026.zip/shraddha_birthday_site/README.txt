# Shraddha Birthday Surprise ❤️

1. Open `index.html` to preview the page.
2. Put your photos inside the `photos` folder and edit the gallery in `index.html` to point to them.
3. Add your legally obtained copy of the song as `song.mp3` in the main folder, then set the audio source to `song.mp3`.
4. Upload the folder to a static host such as GitHub Pages to get a shareable HTTPS link.

The page is designed mobile-first and includes the interactive reveal, memories, funny quiz, love letter, and birthday finale.
